<form  method="post" action="simpan_data.php">
  <table border="0" align="center">
    <tr>
      <td colspan="3" align ="center"><h2>form inputan </h2> </td>
    </tr>
    <tr>
      <td>Kode_Barang</td>
      <td>:</td>
      <td><input type="text" name="Kode_Barang" /> </td>
    </tr>

    <tr>
      <td>Nama_Barang</td>
      <td>:</td>
      <td><input type="text" name="Nama_Barang" /> </td>
    </tr>

    <tr>
      <td>Satuan</td>
      <td>:</td>
      <td><input type="text" name="Satuan" /> </td>
    </tr>

    <tr>
      <td>Harga_Distributor</td>
      <td>:</td>
      <td><input type="text" name="Harga_Distributor" /> </td>
    </tr>

    <tr>
      <td>Harga_Retail</td>
      <td>:</td>
      <td><input type="text" name="Harga_Retail" /> </td>
    </tr>

    <tr>
      <td>Stok</td>
      <td>:</td>
      <td><input type="text" name="Stok" /> </td>
    </tr>

    <tr>
    <td><input type="submit" name="submit" value= "simpan"/>
        <input type="reset" value=" reset"/></td>
    </tr>
  </table>
</form>

<?php
$host    = "localhost";
$user    = "root";
$pasword ="";
$db="toko_elektronik";

$KoneksiDB=mysqli_connect($host, $user, $pasword, $db);

 ?>
